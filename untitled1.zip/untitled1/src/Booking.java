public class Booking {
    private String customerName;
    private int roomNumber;
    private String checkInDate;
    private String checkOutDate;

    public Booking(String customerName, int roomNumber, String checkInDate, String checkOutDate) {
        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }
    public void displayBookingDetails() {
        System.out.println("Booking Details:");
        System.out.println("Customer Name: " + customerName);
        System.out.println("Room Number: " + roomNumber);
        System.out.println("Check-in Date: " + checkInDate);
        System.out.println("Check-out Date: " + checkOutDate);
    }
}
