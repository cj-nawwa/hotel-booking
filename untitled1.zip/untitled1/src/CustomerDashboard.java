import java.util.Scanner;
public class CustomerDashboard {
    private DataBaseHelper dbHelper;

    public CustomerDashboard(DataBaseHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public void bookRoom() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter room number: ");
        int roomNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter check-in date (YYYY-MM-DD): ");
        String checkInDate = scanner.nextLine();
        System.out.print("Enter check-out date (YYYY-MM-DD): ");
        String checkOutDate = scanner.nextLine();

        Booking booking = new Booking(customerName, roomNumber, checkInDate, checkOutDate);
        dbHelper.addBooking(booking);
        System.out.println("Room booked successfully!");
    }

}
