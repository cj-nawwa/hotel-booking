public class AdminDashboard {
    public void viewAllBookings() {
        System.out.println("Viewing all bookings...");
        // Logic to view all bookings
    }

    public void manageRooms() {
        System.out.println("Managing rooms...");
        // Logic to add, edit, or remove rooms
    }
}
