import java.util.ArrayList;
import java.util.List;
public class DataBaseHelper {
    private List<Booking> bookings = new ArrayList<>();

    public void addBooking(Booking booking) {
        bookings.add(booking);
        System.out.println("Booking added successfully.");
    }

    public List<Booking> getAllBookings() {
        return bookings;
    }
}
