import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Calendar {
    public void displayCurrentDate() {
        System.out.println("Today's Date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")));
    }

    public void displayDaysUntilDate(LocalDate futureDate) {
        LocalDate currentDate = LocalDate.now();
        long daysUntil = java.time.temporal.ChronoUnit.DAYS.between(currentDate, futureDate);
        System.out.println("Days until " + futureDate + ": " + daysUntil);
    }

    public void displayWeekRange() {
        LocalDate currentDate = LocalDate.now();
        LocalDate startOfWeek = currentDate.minusDays(currentDate.getDayOfWeek().getValue() - 1);
        LocalDate endOfWeek = startOfWeek.plusDays(6);
        System.out.println("This week ranges from " + startOfWeek + " to " + endOfWeek);
    }
}
