import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DataBaseHelper dbHelper = new DataBaseHelper();
        AdminDashboard adminDashboard = new AdminDashboard();
        CustomerDashboard customerDashboard = new CustomerDashboard(dbHelper);

        System.out.println("Welcome to the Hotel Booking System");

        while (true) {
            System.out.println("1. Admin Dashboard");
            System.out.println("2. Customer Dashboard");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    adminDashboard.viewAllBookings();
                    break;
                case 2:
                    customerDashboard.bookRoom();
                    break;
                case 3:
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
